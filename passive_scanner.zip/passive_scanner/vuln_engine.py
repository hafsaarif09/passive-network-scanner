import importlib

PLUGIN_MAP = {
    "ssh": "vuln_plugins.ssh",
    "ftp": "vuln_plugins.ftp",
    "http": "vuln_plugins.http",
    "https": "vuln_plugins.http"
}

def analyze_service(service, banner):
    module_name = PLUGIN_MAP.get(service)

    if not module_name:
        return {
            "risk": "Low",
            "issue": "Unknown service",
            "learn": "Service not mapped to a vulnerability plugin."
        }

    plugin = importlib.import_module(module_name)
    return plugin.analyze(banner)

