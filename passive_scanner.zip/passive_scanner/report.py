import json
from datetime import datetime

def generate_json_report(target, findings):
    report = {
        "target": target,
        "scan_type": "Passive Vulnerability Assessment",
        "timestamp": datetime.now().isoformat(),
        "findings": findings
    }

    with open("scan_report.json", "w") as f:
        json.dump(report, f, indent=4)
