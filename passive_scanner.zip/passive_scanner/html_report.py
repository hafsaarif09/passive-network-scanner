from jinja2 import Environment, FileSystemLoader

def generate_html_report(target, findings):
    env = Environment(loader=FileSystemLoader("templates"))
    template = env.get_template("report.html")

    html = template.render(
        target=target,
        findings=findings
    )

    filename = f"scan_report_{target.replace('.', '_')}.html"
    with open(filename, "w") as f:
        f.write(html)

    return filename
