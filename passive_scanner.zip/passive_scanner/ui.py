from rich.console import Console
from rich.panel import Panel

console = Console()

def show_info(text):
    console.print(f"[bold cyan][*][/bold cyan] {text}")

def show_success(text):
    console.print(f"[bold green][+][/bold green] {text}")

def show_warning(text):
    console.print(f"[bold yellow][!][/bold yellow] {text}")

def show_danger(text):
    console.print(f"[bold red][!][/bold red] {text}")

def show_panel(title, content, color):
    console.print(Panel(content, title=title, border_style=color))
