def analyze(banner):
    return {
        "risk": "Medium",
        "issue": "HTTP service exposed",
        "learn": "Unencrypted HTTP traffic can be intercepted. HTTPS is recommended."
    }
