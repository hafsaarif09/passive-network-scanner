def analyze(banner):
    if "OpenSSH" in banner:
        return {
            "risk": "Medium",
            "issue": "SSH service exposed",
            "learn": "Exposed SSH can be targeted for brute-force or credential attacks."
        }

    return {
        "risk": "Low",
        "issue": "SSH detected",
        "learn": "Ensure strong authentication and restricted access."
    }
