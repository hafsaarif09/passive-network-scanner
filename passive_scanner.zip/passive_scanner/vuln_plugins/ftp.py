def analyze(banner):
    if "vsftpd" in banner:
        return {
            "risk": "High",
            "issue": "FTP service exposed",
            "learn": "FTP transmits credentials in plaintext and is insecure."
        }

    return {
        "risk": "Medium",
        "issue": "FTP detected",
        "learn": "Consider using SFTP instead of FTP."
    }
