import ipaddress

def parse_targets(target_input):
    targets = []

    # Multiple IPs (comma separated)
    if "," in target_input:
        targets = [ip.strip() for ip in target_input.split(",")]

    # Subnet (CIDR)
    elif "/" in target_input:
        network = ipaddress.ip_network(target_input, strict=False)
        targets = [str(ip) for ip in network.hosts()]

    # Single IP
    else:
        targets = [target_input]

    return targets
