import socket
import settings

def grab_banner(target, port):
    for _ in range(settings.RETRIES):
        try:
            sock = socket.socket()
            sock.settimeout(settings.TIMEOUT)
            sock.connect((target, port))
            banner = sock.recv(1024).decode(errors="ignore").strip()
            sock.close()
            return banner
        except Exception:
            pass

    return "No banner"

