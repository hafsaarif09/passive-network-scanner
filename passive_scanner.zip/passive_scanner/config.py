SCAN_MODES = {
    "quick": {
        22: "SSH",
        80: "HTTP",
        443: "HTTPS"
    },
    "standard": {
        21: "FTP",
        22: "SSH",
        25: "SMTP",
        80: "HTTP",
        110: "POP3",
        443: "HTTPS"
    },
    "passive": {
        21: "FTP",
        22: "SSH",
        25: "SMTP",
        53: "DNS",
        80: "HTTP",
        110: "POP3",
        143: "IMAP",
        443: "HTTPS"
    }
}
