import socket
import settings

COMMON_PORTS = {
    21: "ftp",
    22: "ssh",
    23: "telnet",
    25: "smtp",
    53: "dns",
    80: "http",
    110: "pop3",
    143: "imap",
    443: "https",
    3306: "mysql"
}

def passive_port_scan(target, ports):
    open_services = []

    for port in ports:
        for _ in range(settings.RETRIES):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(settings.TIMEOUT)
                result = sock.connect_ex((target, port))

                if result == 0:
                    service = COMMON_PORTS.get(port, "unknown")
                    open_services.append({
                        "port": port,
                        "service": service
                    })
                    sock.close()
                    break

                sock.close()

            except Exception:
                pass

    return open_services

