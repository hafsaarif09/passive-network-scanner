# Passive Network Vulnerability Scanner

A **modular, passive network scanning tool** designed for cybersecurity enthusiasts, SOC analysts, and penetration testers.  
It supports **multi-target and subnet scanning**, generates **JSON and SOC-style HTML reports**, and provides **learning insights** for every detected service.

---

## Features

- **Passive Scanning** (non-intrusive, safe)
- **Multi-Target & Subnet Support** (`127.0.0.1`, `192.168.1.0/24`)
- **Service Banner Grabbing**
- **Plugin-based Vulnerability Engine**
- **Learning Mode** (explains why a service may be risky)
- **JSON Reports**
- **HTML SOC-style Reports**
- **Configurable Timeout & Retries**
- **System-wide CLI Tool** (`passive-scan`)

---

## Installation (Kali Linux)

```bash
git clone <your-repo-url>
cd passive_scanner
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
sudo mv scanner /usr/local/bin/passive-scan
